import React from 'react';
import ManageSetups from '../components/ManageSetup';

const ManageSetupsView = () => {
    return (
        <>
            <main>
                <ManageSetups />
            </main>
        </>
    );
};

export default ManageSetupsView;