import UpdateSetupForm from "../components/UpdateSetupForm";
const UpdateSetupView = () => {
    return (
        <>
            <main>
                <UpdateSetupForm />
            </main>
        </>
    )
}

export default UpdateSetupView;